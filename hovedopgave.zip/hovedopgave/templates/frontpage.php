<?php 
/* 
Template Name: Frontpage
*/
get_header();
?>

<div class="hero">HERO</div>

<?php get_footer(); ?>