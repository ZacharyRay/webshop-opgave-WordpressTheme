# abtion-theme

### Install dependencies 
`npm i`

### During development
###### Running webpack in watch mode
`npm run watch`

### During production
###### Compile production optimized assets
`npm run build`
